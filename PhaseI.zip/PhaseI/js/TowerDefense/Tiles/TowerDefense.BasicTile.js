TowerDefense.BasicTile = function () {
    TowerDefense.Tile.call( this );
}

TowerDefense.BasicTile.prototype = Object.create( TowerDefense.Tile.prototype );